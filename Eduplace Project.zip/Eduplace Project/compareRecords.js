function recordCompare()
  {
    const fs=require('fs');
    var data1,data2;
    fs.readFile('Staging3.txt',function(err,data)
      {
          data1=data.toString().split('/www/stg.eduplace.com/docs');
          //console.log(data1)
          const el1 = data1[data1.length -1]
          const dataOneTrimEnd = el1.split('\r\n');
          console.log(dataOneTrimEnd, "Tr1")
          data1.pop()
          data1.push(`${dataOneTrimEnd[0]}\r\n`)
		  console.log(data1[data1.length -1], "Last element");
          console.log(data1, ">>>>>>>>>>>>>>>>>>>>>>>>Data1 Records in Array")
          console.log(el1, ">>>>>>>>>>>>>>>>>>>")
        fs.readFile('Production-Listing.txt',function(err,data)
          {
            let writer1;
            // console.log(typeof data);
            data2=data.toString().split('/www/eduplace.com/docs');
            const el2 = data2[data2.length -1]
            const dataSecondTrimEnd = el2.split('\r\n');
            console.log(dataSecondTrimEnd, "ddddddddddd")
            data2.pop()
            data2.push(`${dataSecondTrimEnd[0]}\r\n`)
            console.log(data2, '>>>>>>>>>>>>>>>>>>>>>>>> Data2 records in array')
            function sortAnyArray(a,b) { return a>b ? 1 : (a===b ? 0 : -1); }
            function filterArrayByAnotherArray(searchArray, filterArray) 
              {
                searchArray.sort(sortAnyArray);
                filterArray.sort(sortAnyArray);
                // Progressive Linear Search
                var i = 0;
                return searchArray.filter(function(currentValue){
                  while (filterArray[i] < currentValue) i=i+1|0;
                  // +undefined = NaN, which is always false for <, avoiding an infinite loop
                  return filterArray[i] !== currentValue;
                });
              }
            const result = filterArrayByAnotherArray(data1, data2)
            console.log(result, ">>>>>>>>>>..");
            console.log(result.length, "Records are different in first file");
            if(result.length>0)
			{
				const firstElement = result[0]
				result[0] = `/www/stg.eduplace.com/docs${firstElement}`
			}
            writer1= fs.createWriteStream('final.txt',{
              //flags:'a'
            });
            writer1.write(`${result.join('/www/stg.eduplace.com/docs')}`);
            console.log("Sucessfull Write in Final.txt file")
        })
    })
}
recordCompare();